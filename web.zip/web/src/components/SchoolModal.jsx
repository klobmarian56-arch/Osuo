import { useState } from "react";
import { X, Upload, FileText, Plus, Trash2 } from "lucide-react";
import useUpload from "@/utils/useUpload";

export default function SchoolModal({ school, onClose, onSave, isLoading }) {
  const [formData, setFormData] = useState({
    name: school?.name || "",
    district: school?.district || "",
    location: school?.location || "",
    school_type: school?.school_type || "",
    enrollment: school?.enrollment || "",
    phone: school?.phone || "",
    email: school?.email || "",
    director: school?.director || "",
    status: school?.status || "active",
    osuo_number: school?.osuo_number || "",
    is_online: school?.is_online || true,
    license_series: school?.license_series || "",
    license_number: school?.license_number || "",
    license_pdf_url: school?.license_pdf_url || "",
    license_agreement_pdf_url: school?.license_agreement_pdf_url || "",
    license_issued_by: school?.license_issued_by || "",
    license_issue_date: school?.license_issue_date || "",
    license_expiry_date: school?.license_expiry_date || "",
    license_valid:
      school?.license_valid !== undefined ? school?.license_valid : true,
    contract_number: school?.contract_number || "",
    decision_number: school?.decision_number || "",
    school_email: school?.school_email || "",
    director_contact: school?.director_contact || "",
    logo_url: school?.logo_url || "",
    custom_fields: school?.custom_fields || {},
  });

  const [upload, { loading: uploading }] = useUpload();
  const [newFieldName, setNewFieldName] = useState("");
  const [newFieldValue, setNewFieldValue] = useState("");

  const handleFileUpload = async (fieldName, file) => {
    if (!file) return;
    const { url, error } = await upload({ file });
    if (error) {
      alert("Помилка завантаження файлу");
      return;
    }
    setFormData({ ...formData, [fieldName]: url });
  };

  const handleLogoUpload = async (file) => {
    if (!file) return;
    const { url, error } = await upload({ file });
    if (error) {
      alert("Помилка завантаження логотипу");
      return;
    }
    setFormData({ ...formData, logo_url: url });
  };

  const addCustomField = () => {
    if (!newFieldName.trim()) return;
    setFormData({
      ...formData,
      custom_fields: {
        ...formData.custom_fields,
        [newFieldName]: newFieldValue,
      },
    });
    setNewFieldName("");
    setNewFieldValue("");
  };

  const removeCustomField = (key) => {
    const updated = { ...formData.custom_fields };
    delete updated[key];
    setFormData({ ...formData, custom_fields: updated });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 overflow-y-auto">
      <div className="bg-white rounded-lg shadow-xl w-[800px] max-h-[90vh] overflow-auto my-8">
        <div className="sticky top-0 bg-white p-6 border-b border-[#E4E9F2] flex items-center justify-between z-10">
          <h2 className="text-lg font-semibold text-[#2A2E45]">
            {school ? "Редагувати школу" : "Додати школу"}
          </h2>
          <button
            onClick={onClose}
            className="text-[#8A8FA6] hover:text-[#2A2E45]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Основна інформація */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-[#2A2E45] border-b border-[#E4E9F2] pb-2">
              Основна інформація
            </h3>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-[#2A2E45] mb-1">
                  Номер ОСУО *
                </label>
                <input
                  type="text"
                  value={formData.osuo_number}
                  onChange={(e) =>
                    setFormData({ ...formData, osuo_number: e.target.value })
                  }
                  className="w-full px-3 py-2 border border-[#E4E9F2] rounded text-sm focus:outline-none focus:ring-2 focus:ring-[#1570FF]"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-[#2A2E45] mb-1">
                  Назва школи *
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) =>
                    setFormData({ ...formData, name: e.target.value })
                  }
                  className="w-full px-3 py-2 border border-[#E4E9F2] rounded text-sm focus:outline-none focus:ring-2 focus:ring-[#1570FF]"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-[#2A2E45] mb-1">
                  Район *
                </label>
                <input
                  type="text"
                  value={formData.district}
                  onChange={(e) =>
                    setFormData({ ...formData, district: e.target.value })
                  }
                  className="w-full px-3 py-2 border border-[#E4E9F2] rounded text-sm focus:outline-none focus:ring-2 focus:ring-[#1570FF]"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-[#2A2E45] mb-1">
                  Тип школи *
                </label>
                <select
                  value={formData.school_type}
                  onChange={(e) =>
                    setFormData({ ...formData, school_type: e.target.value })
                  }
                  className="w-full px-3 py-2 border border-[#E4E9F2] rounded text-sm focus:outline-none focus:ring-2 focus:ring-[#1570FF]"
                  required
                >
                  <option value="">Оберіть тип</option>
                  <option value="Загальноосвітня">Загальноосвітня</option>
                  <option value="Ліцей">Ліцей</option>
                  <option value="Гімназія">Гімназія</option>
                  <option value="Спеціалізована">Спеціалізована</option>
                  <option value="Навчально-виховний комплекс">НВК</option>
                  <option value="Онлайн">Онлайн</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-[#2A2E45] mb-1">
                  Кількість учнів
                </label>
                <input
                  type="number"
                  value={formData.enrollment}
                  onChange={(e) =>
                    setFormData({ ...formData, enrollment: e.target.value })
                  }
                  className="w-full px-3 py-2 border border-[#E4E9F2] rounded text-sm focus:outline-none focus:ring-2 focus:ring-[#1570FF]"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-[#2A2E45] mb-1">
                Адреса *
              </label>
              <input
                type="text"
                value={formData.location}
                onChange={(e) =>
                  setFormData({ ...formData, location: e.target.value })
                }
                className="w-full px-3 py-2 border border-[#E4E9F2] rounded text-sm focus:outline-none focus:ring-2 focus:ring-[#1570FF]"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-[#2A2E45] mb-1">
                Логотип школи
              </label>
              <div className="flex items-center space-x-3">
                {formData.logo_url && (
                  <img
                    src={formData.logo_url}
                    alt="Logo"
                    className="w-12 h-12 rounded object-cover"
                  />
                )}
                <label className="cursor-pointer px-3 py-2 border border-[#E4E9F2] rounded text-sm hover:bg-[#F7F9FC] flex items-center space-x-2">
                  <Upload className="w-4 h-4" />
                  <span>{uploading ? "Завантаження..." : "Завантажити"}</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => handleLogoUpload(e.target.files[0])}
                    className="hidden"
                    disabled={uploading}
                  />
                </label>
              </div>
            </div>
          </div>

          {/* Ліцензія */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-[#2A2E45] border-b border-[#E4E9F2] pb-2">
              Ліцензія
            </h3>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-[#2A2E45] mb-1">
                  Серія ліцензії
                </label>
                <input
                  type="text"
                  value={formData.license_series}
                  onChange={(e) =>
                    setFormData({ ...formData, license_series: e.target.value })
                  }
                  className="w-full px-3 py-2 border border-[#E4E9F2] rounded text-sm focus:outline-none focus:ring-2 focus:ring-[#1570FF]"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-[#2A2E45] mb-1">
                  Номер ліцензії
                </label>
                <input
                  type="text"
                  value={formData.license_number}
                  onChange={(e) =>
                    setFormData({ ...formData, license_number: e.target.value })
                  }
                  className="w-full px-3 py-2 border border-[#E4E9F2] rounded text-sm focus:outline-none focus:ring-2 focus:ring-[#1570FF]"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-[#2A2E45] mb-1">
                  Файл ліцензії (PDF)
                </label>
                <label className="cursor-pointer px-3 py-2 border border-[#E4E9F2] rounded text-sm hover:bg-[#F7F9FC] flex items-center space-x-2 justify-center">
                  <FileText className="w-4 h-4" />
                  <span>
                    {formData.license_pdf_url ? "Замінити" : "Завантажити"}
                  </span>
                  <input
                    type="file"
                    accept=".pdf"
                    onChange={(e) =>
                      handleFileUpload("license_pdf_url", e.target.files[0])
                    }
                    className="hidden"
                    disabled={uploading}
                  />
                </label>
                {formData.license_pdf_url && (
                  <a
                    href={formData.license_pdf_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs text-[#1570FF] hover:underline mt-1 block"
                  >
                    Переглянути файл
                  </a>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-[#2A2E45] mb-1">
                  Договір (PDF)
                </label>
                <label className="cursor-pointer px-3 py-2 border border-[#E4E9F2] rounded text-sm hover:bg-[#F7F9FC] flex items-center space-x-2 justify-center">
                  <FileText className="w-4 h-4" />
                  <span>
                    {formData.license_agreement_pdf_url
                      ? "Замінити"
                      : "Завантажити"}
                  </span>
                  <input
                    type="file"
                    accept=".pdf"
                    onChange={(e) =>
                      handleFileUpload(
                        "license_agreement_pdf_url",
                        e.target.files[0],
                      )
                    }
                    className="hidden"
                    disabled={uploading}
                  />
                </label>
                {formData.license_agreement_pdf_url && (
                  <a
                    href={formData.license_agreement_pdf_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs text-[#1570FF] hover:underline mt-1 block"
                  >
                    Переглянути файл
                  </a>
                )}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-[#2A2E45] mb-1">
                Ким видано ліцензію
              </label>
              <input
                type="text"
                value={formData.license_issued_by}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    license_issued_by: e.target.value,
                  })
                }
                className="w-full px-3 py-2 border border-[#E4E9F2] rounded text-sm focus:outline-none focus:ring-2 focus:ring-[#1570FF]"
              />
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-[#2A2E45] mb-1">
                  Дата видачі
                </label>
                <input
                  type="date"
                  value={formData.license_issue_date}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      license_issue_date: e.target.value,
                    })
                  }
                  className="w-full px-3 py-2 border border-[#E4E9F2] rounded text-sm focus:outline-none focus:ring-2 focus:ring-[#1570FF]"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-[#2A2E45] mb-1">
                  Термін дії
                </label>
                <input
                  type="date"
                  value={formData.license_expiry_date}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      license_expiry_date: e.target.value,
                    })
                  }
                  className="w-full px-3 py-2 border border-[#E4E9F2] rounded text-sm focus:outline-none focus:ring-2 focus:ring-[#1570FF]"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-[#2A2E45] mb-1">
                  Дійсність ліцензії
                </label>
                <div className="flex space-x-2">
                  <button
                    type="button"
                    onClick={() =>
                      setFormData({ ...formData, license_valid: true })
                    }
                    className={`flex-1 px-3 py-2 rounded text-sm ${
                      formData.license_valid
                        ? "bg-green-500 text-white"
                        : "border border-[#E4E9F2] text-[#2A2E45] hover:bg-[#F7F9FC]"
                    }`}
                  >
                    ДІЙСНИЙ
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      setFormData({ ...formData, license_valid: false })
                    }
                    className={`flex-1 px-3 py-2 rounded text-sm ${
                      !formData.license_valid
                        ? "bg-red-500 text-white"
                        : "border border-[#E4E9F2] text-[#2A2E45] hover:bg-[#F7F9FC]"
                    }`}
                  >
                    НЕДІЙСНИЙ
                  </button>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-[#2A2E45] mb-1">
                  Номер договору
                </label>
                <input
                  type="text"
                  value={formData.contract_number}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      contract_number: e.target.value,
                    })
                  }
                  className="w-full px-3 py-2 border border-[#E4E9F2] rounded text-sm focus:outline-none focus:ring-2 focus:ring-[#1570FF]"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-[#2A2E45] mb-1">
                  Номер рішення
                </label>
                <input
                  type="text"
                  value={formData.decision_number}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      decision_number: e.target.value,
                    })
                  }
                  className="w-full px-3 py-2 border border-[#E4E9F2] rounded text-sm focus:outline-none focus:ring-2 focus:ring-[#1570FF]"
                />
              </div>
            </div>
          </div>

          {/* Контактна інформація */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-[#2A2E45] border-b border-[#E4E9F2] pb-2">
              Контактна інформація
            </h3>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-[#2A2E45] mb-1">
                  Email школи
                </label>
                <input
                  type="email"
                  value={formData.school_email}
                  onChange={(e) =>
                    setFormData({ ...formData, school_email: e.target.value })
                  }
                  className="w-full px-3 py-2 border border-[#E4E9F2] rounded text-sm focus:outline-none focus:ring-2 focus:ring-[#1570FF]"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-[#2A2E45] mb-1">
                  Телефон
                </label>
                <input
                  type="text"
                  value={formData.phone}
                  onChange={(e) =>
                    setFormData({ ...formData, phone: e.target.value })
                  }
                  className="w-full px-3 py-2 border border-[#E4E9F2] rounded text-sm focus:outline-none focus:ring-2 focus:ring-[#1570FF]"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-[#2A2E45] mb-1">
                  Директор
                </label>
                <input
                  type="text"
                  value={formData.director}
                  onChange={(e) =>
                    setFormData({ ...formData, director: e.target.value })
                  }
                  className="w-full px-3 py-2 border border-[#E4E9F2] rounded text-sm focus:outline-none focus:ring-2 focus:ring-[#1570FF]"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-[#2A2E45] mb-1">
                  Зворотній зв'язок з директором
                </label>
                <input
                  type="text"
                  value={formData.director_contact}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      director_contact: e.target.value,
                    })
                  }
                  className="w-full px-3 py-2 border border-[#E4E9F2] rounded text-sm focus:outline-none focus:ring-2 focus:ring-[#1570FF]"
                  placeholder="Email або телефон"
                />
              </div>
            </div>
          </div>

          {/* Додаткові поля */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-[#2A2E45] border-b border-[#E4E9F2] pb-2">
              Додаткові поля
            </h3>

            {Object.entries(formData.custom_fields).map(([key, value]) => (
              <div key={key} className="flex items-center space-x-2">
                <input
                  type="text"
                  value={key}
                  disabled
                  className="flex-1 px-3 py-2 border border-[#E4E9F2] rounded text-sm bg-[#F7F9FC]"
                />
                <input
                  type="text"
                  value={value}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      custom_fields: {
                        ...formData.custom_fields,
                        [key]: e.target.value,
                      },
                    })
                  }
                  className="flex-1 px-3 py-2 border border-[#E4E9F2] rounded text-sm focus:outline-none focus:ring-2 focus:ring-[#1570FF]"
                />
                <button
                  type="button"
                  onClick={() => removeCustomField(key)}
                  className="p-2 text-red-600 hover:bg-red-50 rounded"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}

            <div className="flex items-center space-x-2">
              <input
                type="text"
                value={newFieldName}
                onChange={(e) => setNewFieldName(e.target.value)}
                placeholder="Назва поля"
                className="flex-1 px-3 py-2 border border-[#E4E9F2] rounded text-sm focus:outline-none focus:ring-2 focus:ring-[#1570FF]"
              />
              <input
                type="text"
                value={newFieldValue}
                onChange={(e) => setNewFieldValue(e.target.value)}
                placeholder="Значення"
                className="flex-1 px-3 py-2 border border-[#E4E9F2] rounded text-sm focus:outline-none focus:ring-2 focus:ring-[#1570FF]"
              />
              <button
                type="button"
                onClick={addCustomField}
                className="px-3 py-2 bg-[#1570FF] text-white rounded text-sm hover:bg-[#0F5FE6] flex items-center space-x-1"
              >
                <Plus className="w-4 h-4" />
                <span>Додати</span>
              </button>
            </div>
          </div>

          {/* Actions */}
          <div className="flex justify-end space-x-3 pt-4 border-t border-[#E4E9F2]">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-[#E4E9F2] rounded text-sm text-[#2A2E45] hover:bg-[#F7F9FC]"
              disabled={isLoading || uploading}
            >
              Скасувати
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-[#1570FF] text-white rounded text-sm hover:bg-[#0F5FE6] disabled:opacity-50"
              disabled={isLoading || uploading}
            >
              {isLoading ? "Збереження..." : "Зберегти"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
