import sql from "@/app/api/utils/sql";
import { hash } from "argon2";

// Створити першого ОСУО директора
// ВАЖЛИВО: Видаліть цей файл після створення першого адміністратора!
export async function POST(request) {
  try {
    const body = await request.json();
    const { email, password, first_name, last_name } = body;

    if (!email || !password) {
      return Response.json(
        { error: "Email and password required" },
        { status: 400 },
      );
    }

    // Створюємо користувача в auth_users
    const userId = crypto.randomUUID();
    const passwordHash = await hash(password);

    // Створюємо auth_users запис
    await sql`
      INSERT INTO auth_users (id, email, name, "emailVerified")
      VALUES (${userId}, ${email}, ${first_name ? `${first_name} ${last_name || ""}`.trim() : email}, null)
    `;

    // Створюємо auth_accounts запис
    await sql`
      INSERT INTO auth_accounts ("userId", provider, type, "providerAccountId", password)
      VALUES (${userId}, 'credentials', 'credentials', ${userId}, ${passwordHash})
    `;

    // Створюємо users запис з роллю osuo_director
    await sql`
      INSERT INTO users (id, email, role, first_name, last_name)
      VALUES (${userId}, ${email}, 'osuo_director', ${first_name || null}, ${last_name || null})
    `;

    return Response.json(
      {
        success: true,
        message: "ОСУО директор створений. ВИДАЛІТЬ ЦЕЙ ФАЙЛ ЗАРАЗ!",
      },
      { status: 201 },
    );
  } catch (error) {
    console.error("Error creating OSUO director:", error);
    return Response.json(
      { error: "Failed to create OSUO director" },
      { status: 500 },
    );
  }
}
