import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

// Get all schools with optional search and filters
export async function GET(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const currentUser =
      await sql`SELECT role, school_id FROM users WHERE id = ${session.user.id}`;
    if (!currentUser[0]) {
      return Response.json({ error: "User not found" }, { status: 404 });
    }

    const { role, school_id } = currentUser[0];

    const { searchParams } = new URL(request.url);
    const search = searchParams.get("search");
    const status = searchParams.get("status");
    const licenseStatus = searchParams.get("licenseStatus");

    let query = "SELECT * FROM schools WHERE 1=1";
    const values = [];
    let paramCount = 0;

    // Директор бачить тільки свою школу
    if (role === "school_director" && school_id) {
      paramCount++;
      query += ` AND id = $${paramCount}`;
      values.push(school_id);
    }

    if (search) {
      paramCount++;
      query += ` AND (LOWER(osuo_number) LIKE LOWER($${paramCount}) OR LOWER(name) LIKE LOWER($${paramCount}))`;
      values.push(`%${search}%`);
    }

    if (status) {
      paramCount++;
      query += ` AND status = $${paramCount}`;
      values.push(status);
    }

    if (licenseStatus === "valid") {
      paramCount++;
      query += ` AND license_valid = $${paramCount}`;
      values.push(true);
    } else if (licenseStatus === "invalid") {
      paramCount++;
      query += ` AND license_valid = $${paramCount}`;
      values.push(false);
    }

    query += " ORDER BY name ASC";

    const schools = await sql(query, values);
    return Response.json({ schools });
  } catch (error) {
    console.error("Error fetching schools:", error);
    return Response.json({ error: "Failed to fetch schools" }, { status: 500 });
  }
}

// Create a new school
export async function POST(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const currentUser =
      await sql`SELECT role FROM users WHERE id = ${session.user.id}`;
    if (
      !currentUser[0] ||
      !["osuo_director", "admin"].includes(currentUser[0].role)
    ) {
      return Response.json({ error: "Forbidden" }, { status: 403 });
    }

    const body = await request.json();
    const {
      name,
      location,
      business_activity_type,
      enrollment,
      director,
      status,
      osuo_number,
      is_online,
      license_series,
      license_number,
      license_pdf_url,
      license_agreement_pdf_url,
      license_issued_by,
      license_issue_date,
      license_expiry_date,
      license_valid,
      contract_number,
      decision_number,
      school_email,
      director_contact,
      logo_url,
      custom_fields,
    } = body;

    if (!name || !osuo_number) {
      return Response.json(
        { error: "Missing required fields" },
        { status: 400 },
      );
    }

    const result = await sql`
      INSERT INTO schools (
        name, location, business_activity_type, enrollment, director, status,
        osuo_number, is_online, license_series, license_number, license_pdf_url,
        license_agreement_pdf_url, license_issued_by, license_issue_date,
        license_expiry_date, license_valid, contract_number, decision_number,
        school_email, director_contact, logo_url, custom_fields, last_updated_by, last_updated_at
      )
      VALUES (
        ${name}, ${location || null}, ${business_activity_type || null}, ${enrollment || null}, 
        ${director || null}, ${status || "active"},
        ${osuo_number}, ${is_online || false}, ${license_series || null}, 
        ${license_number || null}, ${license_pdf_url || null}, ${license_agreement_pdf_url || null},
        ${license_issued_by || null}, ${license_issue_date || null}, ${license_expiry_date || null},
        ${license_valid !== undefined ? license_valid : true}, ${contract_number || null}, 
        ${decision_number || null}, ${school_email || null}, ${director_contact || null},
        ${logo_url || null}, ${custom_fields ? JSON.stringify(custom_fields) : "{}"}, 
        ${session.user.email}, CURRENT_TIMESTAMP
      )
      RETURNING *
    `;

    return Response.json({ school: result[0] }, { status: 201 });
  } catch (error) {
    console.error("Error creating school:", error);
    return Response.json({ error: "Failed to create school" }, { status: 500 });
  }
}
