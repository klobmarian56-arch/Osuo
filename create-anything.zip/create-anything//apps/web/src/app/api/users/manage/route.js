import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";
import { hash } from "argon2";

// Get all users (only for OSUO directors and admins)
export async function GET() {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const currentUser =
      await sql`SELECT role FROM users WHERE id = ${session.user.id}`;
    if (
      !currentUser[0] ||
      !["osuo_director", "admin"].includes(currentUser[0].role)
    ) {
      return Response.json({ error: "Forbidden" }, { status: 403 });
    }

    const users = await sql`
      SELECT u.*, s.name as school_name
      FROM users u
      LEFT JOIN schools s ON u.school_id = s.id
      ORDER BY u.created_at DESC
    `;

    return Response.json({ users });
  } catch (error) {
    console.error("Error fetching users:", error);
    return Response.json({ error: "Failed to fetch users" }, { status: 500 });
  }
}

// Create new user (only for OSUO directors)
export async function POST(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const currentUser =
      await sql`SELECT role FROM users WHERE id = ${session.user.id}`;
    if (!currentUser[0] || currentUser[0].role !== "osuo_director") {
      return Response.json({ error: "Forbidden" }, { status: 403 });
    }

    const body = await request.json();
    const {
      email,
      password,
      role,
      first_name,
      last_name,
      patronymic,
      phone_number,
      school_id,
    } = body;

    if (!email || !password || !role) {
      return Response.json(
        { error: "Missing required fields" },
        { status: 400 },
      );
    }

    // Створюємо користувача в auth_users
    const userId = crypto.randomUUID();
    const passwordHash = await hash(password);

    await sql`
      INSERT INTO auth_users (id, email, name, "emailVerified")
      VALUES (${userId}, ${email}, ${first_name ? `${first_name} ${last_name || ""}`.trim() : email}, null)
    `;

    await sql`
      INSERT INTO auth_accounts ("userId", provider, type, "providerAccountId", password)
      VALUES (${userId}, 'credentials', 'credentials', ${userId}, ${passwordHash})
    `;

    await sql`
      INSERT INTO users (id, email, role, first_name, last_name, patronymic, phone_number, school_id)
      VALUES (${userId}, ${email}, ${role}, ${first_name || null}, ${last_name || null}, 
              ${patronymic || null}, ${phone_number || null}, ${school_id || null})
    `;

    return Response.json({ success: true, userId }, { status: 201 });
  } catch (error) {
    console.error("Error creating user:", error);
    return Response.json({ error: "Failed to create user" }, { status: 500 });
  }
}
