import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

// Get a single school by ID
export async function GET(request, { params }) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { id } = params;
    const result = await sql`SELECT * FROM schools WHERE id = ${id}`;

    if (result.length === 0) {
      return Response.json({ error: "School not found" }, { status: 404 });
    }

    return Response.json({ school: result[0] });
  } catch (error) {
    console.error("Error fetching school:", error);
    return Response.json({ error: "Failed to fetch school" }, { status: 500 });
  }
}

// Update a school
export async function PUT(request, { params }) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const currentUser =
      await sql`SELECT role, school_id FROM users WHERE id = ${session.user.id}`;
    if (!currentUser[0]) {
      return Response.json({ error: "User not found" }, { status: 404 });
    }

    const { role, school_id } = currentUser[0];
    const { id } = params;

    // Перевіряємо права доступу
    if (role === "school_director" && school_id !== parseInt(id)) {
      return Response.json(
        { error: "You can only edit your own school" },
        { status: 403 },
      );
    }
    if (role === "viewer") {
      return Response.json(
        { error: "Viewers cannot edit schools" },
        { status: 403 },
      );
    }

    const body = await request.json();

    const updates = [];
    const values = [];
    let paramCount = 0;

    const allowedFields = [
      "name",
      "location",
      "business_activity_type",
      "enrollment",
      "director",
      "status",
      "osuo_number",
      "is_online",
      "license_series",
      "license_number",
      "license_pdf_url",
      "license_agreement_pdf_url",
      "license_issued_by",
      "license_issue_date",
      "license_expiry_date",
      "license_valid",
      "contract_number",
      "decision_number",
      "school_email",
      "director_contact",
      "logo_url",
      "custom_fields",
    ];

    for (const field of allowedFields) {
      if (body[field] !== undefined) {
        paramCount++;
        if (field === "custom_fields") {
          updates.push(`${field} = $${paramCount}`);
          values.push(JSON.stringify(body[field]));
        } else {
          updates.push(`${field} = $${paramCount}`);
          values.push(body[field]);
        }
      }
    }

    if (updates.length === 0) {
      return Response.json({ error: "No fields to update" }, { status: 400 });
    }

    // Додаємо інформацію про оновлення
    paramCount++;
    updates.push(`updated_at = $${paramCount}`);
    values.push(new Date().toISOString());

    paramCount++;
    updates.push(`last_updated_by = $${paramCount}`);
    values.push(session.user.email);

    paramCount++;
    updates.push(`last_updated_at = $${paramCount}`);
    values.push(new Date().toISOString());

    paramCount++;
    values.push(id);

    const query = `UPDATE schools SET ${updates.join(", ")} WHERE id = $${paramCount} RETURNING *`;
    const result = await sql(query, values);

    if (result.length === 0) {
      return Response.json({ error: "School not found" }, { status: 404 });
    }

    return Response.json({ school: result[0] });
  } catch (error) {
    console.error("Error updating school:", error);
    return Response.json({ error: "Failed to update school" }, { status: 500 });
  }
}

// Delete a school
export async function DELETE(request, { params }) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const currentUser =
      await sql`SELECT role FROM users WHERE id = ${session.user.id}`;
    if (
      !currentUser[0] ||
      !["osuo_director", "admin"].includes(currentUser[0].role)
    ) {
      return Response.json({ error: "Forbidden" }, { status: 403 });
    }

    const { id } = params;
    const result = await sql`DELETE FROM schools WHERE id = ${id} RETURNING *`;

    if (result.length === 0) {
      return Response.json({ error: "School not found" }, { status: 404 });
    }

    return Response.json({ success: true });
  } catch (error) {
    console.error("Error deleting school:", error);
    return Response.json({ error: "Failed to delete school" }, { status: 500 });
  }
}
