import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

// Get certificate orders
export async function GET() {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const currentUser =
      await sql`SELECT role, school_id FROM users WHERE id = ${session.user.id}`;
    if (!currentUser[0]) {
      return Response.json({ error: "User not found" }, { status: 404 });
    }

    const { role, school_id } = currentUser[0];

    let orders;
    if (role === "school_director" && school_id) {
      // Директор бачить тільки замовлення своєї школи
      orders = await sql`
        SELECT co.*, s.name as school_name, u.email as ordered_by_email
        FROM certificate_orders co
        LEFT JOIN schools s ON co.school_id = s.id
        LEFT JOIN users u ON co.ordered_by = u.id
        WHERE co.school_id = ${school_id}
        ORDER BY co.created_at DESC
      `;
    } else if (["osuo_director", "admin"].includes(role)) {
      // ОСУО директор та адмін бачать всі замовлення
      orders = await sql`
        SELECT co.*, s.name as school_name, u.email as ordered_by_email
        FROM certificate_orders co
        LEFT JOIN schools s ON co.school_id = s.id
        LEFT JOIN users u ON co.ordered_by = u.id
        ORDER BY co.created_at DESC
      `;
    } else {
      return Response.json({ error: "Forbidden" }, { status: 403 });
    }

    return Response.json({ orders });
  } catch (error) {
    console.error("Error fetching certificate orders:", error);
    return Response.json({ error: "Failed to fetch orders" }, { status: 500 });
  }
}

// Create certificate order
export async function POST(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const currentUser =
      await sql`SELECT role, school_id FROM users WHERE id = ${session.user.id}`;
    if (!currentUser[0]) {
      return Response.json({ error: "User not found" }, { status: 404 });
    }

    const { role, school_id } = currentUser[0];

    // Тільки директори шкіл можуть створювати замовлення
    if (role !== "school_director" || !school_id) {
      return Response.json(
        { error: "Only school directors can create orders" },
        { status: 403 },
      );
    }

    const body = await request.json();
    const {
      student_first_name,
      student_last_name,
      student_patronymic,
      student_birth_date,
      completion_year,
      notes,
    } = body;

    if (
      !student_first_name ||
      !student_last_name ||
      !student_birth_date ||
      !completion_year
    ) {
      return Response.json(
        { error: "Missing required fields" },
        { status: 400 },
      );
    }

    const result = await sql`
      INSERT INTO certificate_orders (
        school_id, ordered_by, student_first_name, student_last_name, 
        student_patronymic, student_birth_date, completion_year, notes
      )
      VALUES (
        ${school_id}, ${session.user.id}, ${student_first_name}, ${student_last_name},
        ${student_patronymic || null}, ${student_birth_date}, ${completion_year}, ${notes || null}
      )
      RETURNING *
    `;

    return Response.json({ order: result[0] }, { status: 201 });
  } catch (error) {
    console.error("Error creating certificate order:", error);
    return Response.json({ error: "Failed to create order" }, { status: 500 });
  }
}
