"use client";

import { useState } from "react";
import useAuth from "@/utils/useAuth";

export default function SignInPage() {
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const { signInWithCredentials } = useAuth();

  const onSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    if (!email || !password) {
      setError("Будь ласка, заповніть всі поля");
      setLoading(false);
      return;
    }

    try {
      await signInWithCredentials({
        email,
        password,
        callbackUrl: "/",
        redirect: true,
      });
    } catch (err) {
      setError("Невірний email або пароль");
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen w-full items-center justify-center bg-[#F7F9FC]">
      <form
        onSubmit={onSubmit}
        className="w-full max-w-md rounded-lg bg-white p-8 shadow-lg border border-[#E4E9F2]"
      >
        <h1 className="mb-8 text-center text-2xl font-semibold text-[#2A2E45]">
          Вхід до системи
        </h1>

        <div className="space-y-6">
          <div className="space-y-2">
            <label className="block text-sm font-medium text-[#2A2E45]">
              Електронна адреса
            </label>
            <input
              required
              name="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Введіть email"
              className="w-full px-4 py-3 border border-[#E4E9F2] rounded focus:outline-none focus:ring-2 focus:ring-[#1570FF]"
            />
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-[#2A2E45]">
              Пароль
            </label>
            <input
              required
              name="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-3 border border-[#E4E9F2] rounded focus:outline-none focus:ring-2 focus:ring-[#1570FF]"
              placeholder="Введіть пароль"
            />
          </div>

          {error && (
            <div className="rounded-lg bg-red-50 p-3 text-sm text-red-600">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-lg bg-[#1570FF] px-4 py-3 text-base font-medium text-white hover:bg-[#0F5FE6] focus:outline-none focus:ring-2 focus:ring-[#1570FF] disabled:opacity-50"
          >
            {loading ? "Завантаження..." : "Увійти"}
          </button>
        </div>
      </form>
    </div>
  );
}
