"use client";

import useAuth from "@/utils/useAuth";
import { useEffect } from "react";

export default function LogoutPage() {
  const { signOut } = useAuth();

  useEffect(() => {
    signOut({
      callbackUrl: "/account/signin",
      redirect: true,
    });
  }, [signOut]);

  return (
    <div className="flex min-h-screen w-full items-center justify-center bg-[#F7F9FC]">
      <div className="text-center">
        <div className="text-lg text-[#8A8FA6]">Вихід з системи...</div>
      </div>
    </div>
  );
}
