"use client";

import { useState, useCallback } from "react";
import {
  useQuery,
  useMutation,
  useQueryClient,
  QueryClient,
  QueryClientProvider,
} from "@tanstack/react-query";
import {
  ChevronDown,
  ChevronRight,
  Search,
  Bell,
  Settings,
  Plus,
  Edit3,
  Trash2,
  School,
  Building2,
  Users,
  FileText,
  LayoutDashboard,
  Filter,
  X,
  CheckCircle,
  XCircle,
} from "lucide-react";
import SchoolModal from "@/components/SchoolModal";

const queryClient = new QueryClient();

function SchoolsRegistry() {
  const [selectedSchools, setSelectedSchools] = useState(new Set());
  const [moreExpanded, setMoreExpanded] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterDistrict, setFilterDistrict] = useState("");
  const [filterType, setFilterType] = useState("");
  const [filterStatus, setFilterStatus] = useState("");
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingSchool, setEditingSchool] = useState(null);
  const queryClientInstance = useQueryClient();

  const navItems = [
    { icon: LayoutDashboard, label: "Панель керування", active: true },
    { icon: School, label: "Школи" },
    { icon: Users, label: "Учні" },
    { icon: Building2, label: "Райони" },
    { icon: FileText, label: "Звіти" },
  ];

  const moreItems = [
    { icon: Settings, label: "Налаштування" },
    { icon: FileText, label: "Документація" },
  ];

  // Fetch schools
  const {
    data: schoolsData,
    isLoading,
    error,
  } = useQuery({
    queryKey: ["schools", searchTerm, filterDistrict, filterType, filterStatus],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (searchTerm) params.append("search", searchTerm);
      if (filterDistrict) params.append("district", filterDistrict);
      if (filterType) params.append("schoolType", filterType);
      if (filterStatus) params.append("status", filterStatus);

      const response = await fetch(`/api/schools?${params}`);
      if (!response.ok) {
        throw new Error("Failed to fetch schools");
      }
      const data = await response.json();
      return data.schools;
    },
  });

  // Delete mutation
  const deleteMutation = useMutation({
    mutationFn: async (id) => {
      const response = await fetch(`/api/schools/${id}`, {
        method: "DELETE",
      });
      if (!response.ok) {
        throw new Error("Failed to delete school");
      }
    },
    onSuccess: () => {
      queryClientInstance.invalidateQueries({ queryKey: ["schools"] });
      setSelectedSchools(new Set());
    },
  });

  // Create mutation
  const createMutation = useMutation({
    mutationFn: async (schoolData) => {
      const response = await fetch("/api/schools", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(schoolData),
      });
      if (!response.ok) {
        throw new Error("Failed to create school");
      }
      return response.json();
    },
    onSuccess: () => {
      queryClientInstance.invalidateQueries({ queryKey: ["schools"] });
      setShowAddModal(false);
    },
  });

  // Update mutation
  const updateMutation = useMutation({
    mutationFn: async ({ id, data }) => {
      const response = await fetch(`/api/schools/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!response.ok) {
        throw new Error("Failed to update school");
      }
      return response.json();
    },
    onSuccess: () => {
      queryClientInstance.invalidateQueries({ queryKey: ["schools"] });
      setShowEditModal(false);
      setEditingSchool(null);
    },
  });

  const schools = schoolsData || [];

  const districts = [...new Set(schools.map((s) => s.district))];
  const schoolTypes = [...new Set(schools.map((s) => s.school_type))];

  const toggleSchoolSelection = (schoolId) => {
    const newSelected = new Set(selectedSchools);
    if (newSelected.has(schoolId)) {
      newSelected.delete(schoolId);
    } else {
      newSelected.add(schoolId);
    }
    setSelectedSchools(newSelected);
  };

  const selectAll = () => {
    if (selectedSchools.size === schools.length) {
      setSelectedSchools(new Set());
    } else {
      setSelectedSchools(new Set(schools.map((s) => s.id)));
    }
  };

  const handleDelete = useCallback(
    (id) => {
      if (confirm("Ви впевнені, що хочете видалити цю школу?")) {
        deleteMutation.mutate(id);
      }
    },
    [deleteMutation],
  );

  const handleEdit = useCallback((school) => {
    setEditingSchool(school);
    setShowEditModal(true);
  }, []);

  const handleDeleteSelected = useCallback(() => {
    if (selectedSchools.size === 0) return;
    if (
      confirm(`Ви впевнені, що хочете видалити ${selectedSchools.size} шкіл?`)
    ) {
      selectedSchools.forEach((id) => deleteMutation.mutate(id));
    }
  }, [selectedSchools, deleteMutation]);

  return (
    <div className="flex h-screen bg-white font-inter">
      {/* Left Sidebar */}
      <div className="w-60 bg-[#F7F9FC] flex flex-col">
        {/* User Card */}
        <div className="m-4 mb-6">
          <div className="bg-white rounded border border-[#E4E9F2] h-[72px] flex items-center px-4">
            <div className="w-8 h-8 bg-[#EDF3FF] rounded-full flex items-center justify-center text-[#1570FF] font-semibold text-sm">
              АД
            </div>
            <div className="ml-3 flex-1">
              <div className="font-semibold text-sm text-[#2A2E45]">
                Адміністратор
              </div>
              <div className="text-[11px] text-[#8A8FA6]">admin@schools.ua</div>
            </div>
            <ChevronDown className="w-3 h-3 text-[#8A8FA6]" />
          </div>
        </div>

        {/* Navigation */}
        <div className="flex-1 px-4">
          <div className="text-[11px] font-semibold text-[#8A8FA6] uppercase tracking-wider py-2">
            Навігація
          </div>

          <div className="space-y-1">
            {navItems.map((item, index) => (
              <div
                key={index}
                className={`h-9 flex items-center px-3 rounded cursor-pointer ${
                  item.active
                    ? "bg-[#1570FF] text-white"
                    : "text-[#2A2E45] hover:bg-[#EDF3FF]"
                }`}
              >
                <item.icon className="w-4 h-4 mr-3" />
                <span className="text-sm">{item.label}</span>
              </div>
            ))}
          </div>

          {/* More Section */}
          <div className="mt-6">
            <div className="text-[11px] font-semibold text-[#8A8FA6] uppercase tracking-wider py-2">
              Більше
            </div>

            <div
              className="h-9 flex items-center px-3 rounded cursor-pointer text-[#2A2E45] hover:bg-[#EDF3FF]"
              onClick={() => setMoreExpanded(!moreExpanded)}
            >
              {moreExpanded ? (
                <ChevronDown className="w-4 h-4 mr-3 text-[#6F7689]" />
              ) : (
                <ChevronRight className="w-4 h-4 mr-3 text-[#6F7689]" />
              )}
              <span className="text-sm">Більше</span>
            </div>

            {moreExpanded && (
              <div className="ml-4 space-y-1 mt-1">
                {moreItems.map((item, index) => (
                  <div
                    key={index}
                    className="h-9 flex items-center px-3 rounded cursor-pointer text-[#2A2E45] hover:bg-[#EDF3FF]"
                  >
                    <item.icon className="w-4 h-4 mr-3 text-[#6F7689]" />
                    <span className="text-sm">{item.label}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4">
          <div className="text-[11px] text-[#8A8FA6] text-center">
            © 2026 Реєстр Шкіл України
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Top Bar */}
        <div className="h-14 bg-white border-b border-[#E4E9F2] flex items-center px-6">
          {/* Brand */}
          <div className="font-bold text-base text-[#2A2E45] mr-8">
            Реєстр Шкіл
          </div>

          {/* Search */}
          <div className="flex-1 flex justify-center">
            <div className="relative w-[360px]">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-[#8A8FA6]" />
              <input
                type="text"
                placeholder="Пошук за ОСУО, назвою, адресою, директором..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full h-8 pl-10 pr-4 border border-[#E4E9F2] rounded text-sm placeholder-[#B6BACE] focus:outline-none focus:ring-2 focus:ring-[#1570FF]"
              />
            </div>
          </div>

          {/* Right Controls */}
          <div className="flex items-center space-x-3">
            <button className="w-8 h-8 bg-white border border-[#E4E9F2] rounded-full flex items-center justify-center hover:bg-[#EDF3FF]">
              <Bell className="w-4 h-4 text-[#6F7689]" />
            </button>
            <button className="w-8 h-8 bg-white border border-[#E4E9F2] rounded-full flex items-center justify-center hover:bg-[#EDF3FF]">
              <Settings className="w-4 h-4 text-[#6F7689]" />
            </button>
            <div className="w-8 h-8 bg-[#EDF3FF] rounded-full flex items-center justify-center text-[#1570FF] font-semibold text-sm">
              АД
            </div>
          </div>
        </div>

        {/* Content Area */}
        <div className="flex-1 p-4 overflow-auto">
          {/* Section Header */}
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-4">
              <h1 className="text-base font-semibold text-[#2A2E45]">
                Реєстр Шкіл
              </h1>

              {/* Filter Chips */}
              <div className="flex space-x-2">
                <select
                  value={filterDistrict}
                  onChange={(e) => setFilterDistrict(e.target.value)}
                  className="h-7 px-3 rounded text-xs border border-[#E4E9F2] bg-white text-[#6F7689] hover:bg-[#F7F9FC] focus:outline-none focus:ring-2 focus:ring-[#1570FF]"
                >
                  <option value="">Всі райони</option>
                  {districts.map((d) => (
                    <option key={d} value={d}>
                      {d}
                    </option>
                  ))}
                </select>

                <select
                  value={filterType}
                  onChange={(e) => setFilterType(e.target.value)}
                  className="h-7 px-3 rounded text-xs border border-[#E4E9F2] bg-white text-[#6F7689] hover:bg-[#F7F9FC] focus:outline-none focus:ring-2 focus:ring-[#1570FF]"
                >
                  <option value="">Всі типи</option>
                  {schoolTypes.map((t) => (
                    <option key={t} value={t}>
                      {t}
                    </option>
                  ))}
                </select>

                <select
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value)}
                  className="h-7 px-3 rounded text-xs border border-[#E4E9F2] bg-white text-[#6F7689] hover:bg-[#F7F9FC] focus:outline-none focus:ring-2 focus:ring-[#1570FF]"
                >
                  <option value="">Всі статуси</option>
                  <option value="active">Активні</option>
                  <option value="inactive">Неактивні</option>
                </select>

                {(filterDistrict || filterType || filterStatus) && (
                  <button
                    onClick={() => {
                      setFilterDistrict("");
                      setFilterType("");
                      setFilterStatus("");
                    }}
                    className="h-7 px-3 rounded text-xs border border-[#E4E9F2] bg-white text-[#6F7689] hover:bg-[#F7F9FC] flex items-center space-x-1"
                  >
                    <X className="w-3 h-3" />
                    <span>Скинути</span>
                  </button>
                )}
              </div>
            </div>

            {/* Add Button */}
            <button
              onClick={() => setShowAddModal(true)}
              className="px-4 py-2 bg-[#1570FF] text-white rounded text-sm flex items-center justify-center space-x-2 hover:bg-[#0F5FE6]"
            >
              <Plus className="w-4 h-4" />
              <span>Додати школу</span>
            </button>
          </div>

          {/* Toolbar */}
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-2">
              <button
                onClick={selectAll}
                className="h-8 px-3 border border-[#E4E9F2] rounded text-xs text-[#2A2E45] hover:bg-[#F7F9FC]"
              >
                {selectedSchools.size === schools.length
                  ? "Скасувати вибір"
                  : "Вибрати все"}
              </button>

              {selectedSchools.size > 0 && (
                <button
                  onClick={handleDeleteSelected}
                  className="h-8 px-3 border border-[#E4E9F2] rounded text-xs text-red-600 hover:bg-red-50 flex items-center space-x-1"
                >
                  <Trash2 className="w-3 h-3" />
                  <span>Видалити ({selectedSchools.size})</span>
                </button>
              )}
            </div>

            <div className="text-xs text-[#8A8FA6]">
              Всього: {schools.length} шкіл
            </div>
          </div>

          {/* Schools List */}
          {isLoading ? (
            <div className="text-center py-12 text-[#8A8FA6]">
              Завантаження...
            </div>
          ) : error ? (
            <div className="text-center py-12 text-red-600">
              Помилка завантаження даних
            </div>
          ) : schools.length === 0 ? (
            <div className="text-center py-12 text-[#8A8FA6]">
              Школи не знайдено
            </div>
          ) : (
            <div className="space-y-2">
              {schools.map((school) => (
                <div
                  key={school.id}
                  className={`bg-white rounded border p-4 flex items-center space-x-4 hover:bg-[#FAFBFD] cursor-pointer ${
                    selectedSchools.has(school.id)
                      ? "border-[#1570FF] border-2"
                      : "border-[#E4E9F2]"
                  }`}
                  onClick={() => toggleSchoolSelection(school.id)}
                >
                  {/* Checkbox */}
                  <input
                    type="checkbox"
                    checked={selectedSchools.has(school.id)}
                    onChange={() => toggleSchoolSelection(school.id)}
                    className="w-4 h-4 text-[#1570FF] rounded focus:ring-[#1570FF]"
                    onClick={(e) => e.stopPropagation()}
                  />

                  {/* Logo or Icon */}
                  <div className="w-12 h-12 bg-[#EDF3FF] rounded flex items-center justify-center overflow-hidden">
                    {school.logo_url ? (
                      <img
                        src={school.logo_url}
                        alt={school.name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <School className="w-6 h-6 text-[#1570FF]" />
                    )}
                  </div>

                  {/* School Info */}
                  <div className="flex-1 grid grid-cols-5 gap-4">
                    <div>
                      <div className="font-semibold text-sm text-[#2A2E45]">
                        {school.name}
                      </div>
                      <div className="text-xs text-[#8A8FA6]">
                        {school.osuo_number || "—"}
                      </div>
                    </div>
                    <div>
                      <div className="text-xs text-[#8A8FA6]">Район</div>
                      <div className="text-sm text-[#2A2E45]">
                        {school.district}
                      </div>
                    </div>
                    <div>
                      <div className="text-xs text-[#8A8FA6]">Адреса</div>
                      <div className="text-sm text-[#2A2E45]">
                        {school.location}
                      </div>
                    </div>
                    <div>
                      <div className="text-xs text-[#8A8FA6]">Учнів</div>
                      <div className="text-sm text-[#2A2E45]">
                        {school.enrollment || "—"}
                      </div>
                    </div>
                    <div>
                      <div className="text-xs text-[#8A8FA6]">Ліцензія</div>
                      <div className="flex items-center space-x-1">
                        {school.license_valid ? (
                          <>
                            <CheckCircle className="w-4 h-4 text-green-500" />
                            <span className="text-sm text-green-600">
                              Дійсна
                            </span>
                          </>
                        ) : (
                          <>
                            <XCircle className="w-4 h-4 text-red-500" />
                            <span className="text-sm text-red-600">
                              Недійсна
                            </span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex space-x-2">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleEdit(school);
                      }}
                      className="w-8 h-8 hover:bg-[#EDF3FF] rounded flex items-center justify-center"
                    >
                      <Edit3 className="w-4 h-4 text-[#6F7689]" />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDelete(school.id);
                      }}
                      className="w-8 h-8 hover:bg-red-50 rounded flex items-center justify-center"
                    >
                      <Trash2 className="w-4 h-4 text-red-600" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Add/Edit Modal */}
      {(showAddModal || showEditModal) && (
        <SchoolModal
          school={editingSchool}
          onClose={() => {
            setShowAddModal(false);
            setShowEditModal(false);
            setEditingSchool(null);
          }}
          onSave={(data) => {
            if (editingSchool) {
              updateMutation.mutate({ id: editingSchool.id, data });
            } else {
              createMutation.mutate(data);
            }
          }}
          isLoading={createMutation.isLoading || updateMutation.isLoading}
        />
      )}
    </div>
  );
}

export default function Page() {
  return (
    <QueryClientProvider client={queryClient}>
      <SchoolsRegistry />
    </QueryClientProvider>
  );
}
